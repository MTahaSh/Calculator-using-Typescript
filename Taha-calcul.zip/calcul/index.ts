#! /usr/bin/env node

import inquirer from "inquirer";
import chalk from "chalk";
import chalkAnimation from "chalk-animation";

const sleep = ()=>{
    return new Promise((res)=>{
        setTimeout(res,2000);
    })
}

async function welcome(){
   let rainbowTitle =  chalkAnimation.rainbow("Let's begin the calculation")
   await sleep();
   rainbowTitle.stop();
   console.log(chalk.gray(` 
   _____________________
   |  _________________  |
   | | JO  3.141592654 | |
   | |_________________| |
   |  __ __ __ __ __ __  |
   | |__|__|__|__|__|__| |
   | |__|__|__|__|__|__| |
   | |__|__|__|__|__|__| |
   | |__|__|__|__|__|__| |
   | |__|__|__|__|__|__| |
   | |__|__|__|__|__|__| |
   |  ___ ___ ___   ___  |
   | | 7 | 8 | 9 | | + | |
   | |___|___|___| |___| |
   | | 4 | 5 | 6 | | - | |
   | |___|___|___| |___| |
   | | 1 | 2 | 3 | | x | |
   | |___|___|___| |___| |
   | | . | 0 | = | | / | |
   | |___|___|___| |___| |
   |_____________________|`));
   
}



async function askQuestions()
{
    const answers = await inquirer
    .prompt([
        {
            type:"list",
            name:"operator",
            message: "Which operation would you like to perform??",
            choices:["Addition","Subtraction","Multiplication","Division"]
        },
        {
            type:"number",
            name:"num1",
            message:"Enter the first number: "
        },
        {
            type:"number",
            name:"num2",
            message:"Enter the second number: "
        }
    ]);

    if(answers.operator == "Addition")
        {
            console.log(chalk.blueBright(`${answers.num1} + ${answers.num2} = ${answers.num1+answers.num2}`));    
        }
        else if(answers.operator == "Subtraction")
        {
            console.log(chalk.blueBright(`${answers.num1} - ${answers.num2} = ${answers.num1-answers.num2}`));
        }
        else if(answers.operator == "Multiplication")
        {
            console.log(chalk.blueBright(`${answers.num1} * ${answers.num2} = ${answers.num1*answers.num2}`));
        }
        else if(answers.operator == "Division")
        {
            console.log(chalk.blueBright(`${answers.num1} / ${answers.num2} = ${answers.num1/answers.num2}`));
        }

    
};

async function Restart(){
    do{
        await askQuestions();
        var again = await inquirer
        .prompt({
            type:"input",
            name:"restart",
            message:"Would you like to continue?? Press (Y/y) to restart and (N/n) to stop:"
        })
    }while(again.restart === 'Y' || again.restart === 'y' || again.restart === 'yes' || again.restart === 'YES');
}


await welcome();
Restart();
